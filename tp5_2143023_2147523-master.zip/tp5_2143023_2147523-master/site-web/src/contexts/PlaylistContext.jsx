import React from "react";

const PlaylistContext = React.createContext();

export default PlaylistContext;